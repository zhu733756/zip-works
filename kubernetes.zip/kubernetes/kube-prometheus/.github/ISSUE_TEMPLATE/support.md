---
name: Support
about: If you have questions about kube-prometheus
labels: kind/support
---

This repository now has the new GitHub Discussions enabled: 
https://github.com/coreos/kube-prometheus/discussions

Please create a new discussion to ask for any kind of support, which is not a Bug or Feature Request.

Thank you for being part of this community!

---

We are still happy to chat with you in the #prometheus-operator channel on Kubernetes Slack!

