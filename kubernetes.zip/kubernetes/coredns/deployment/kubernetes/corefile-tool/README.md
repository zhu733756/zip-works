## Corefile-tool

Corefile-tool has moved to https://github.com/coredns/corefile-migration/tree/master/corefile-tool